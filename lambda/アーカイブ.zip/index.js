'use strict';

//LINE Thingsからリクエストを受け取ったら、スルーパスしたユーザーにmessageを投げる。
//メッセージの内容は、
//冷蔵庫のコーラが減ってるよ
//山本さんに教えるため、位置情報を報告してね♪


const line = require('@line/bot-sdk');
const crypto = require('crypto');
const client = new line.Client({ channelAccessToken: process.env.ACCESS_TOKEN });
const messageObject = require('./message_object');
// const beacon = require('./beacon');
// const dynamodb = require('./dynamodb'); 
// const CONST_TEXT = require('./const_text');

var exec = require('exec');
var exec = require('child_process').exec;


/**
 * 以下のコードを追加する
 */
// var Botkit = require('botkit');
// var controller = Botkit.slackbot();
// var bot = controller.spawn({
//     token: "xoxb-10273818935-795416094981-GMSqi1tjglsUVXEuN1xpNgIT"
// }).startRTM(function (err, bot, payload) {
//     if (err) {
//         throw new Error('Could not connect to Slack');
//     }
// });



exports.handler = function (event, context) {
    let signature = crypto.createHmac('sha256', process.env.CHANNEL_SECRET).update(event.body).digest('base64');
    let checkHeader = (event.headers || {})['X-Line-Signature'];
    let body = JSON.parse(event.body);
    if (signature === checkHeader) {
        if (body.events[0].replyToken === '00000000000000000000000000000000') { //接続確認エラー回避
            let lambdaResponse = {
                statusCode: 200,
                headers: { "X-Line-Status": "OK" },
                body: '{"result":"connect check"}'
            };
            console.log('L.30 LINE developers consoleからの疎通確認'); //デバッグ
            context.succeed(lambdaResponse);

        } else {
            //共通処理
            var replyToken = body.events[0].replyToken;
            let userID = body.events[0].source.userId;

            //デバッグ
            console.log('L.39 body=' + JSON.stringify(body));
            console.log('L.45 body.events[0].type=' + body.events[0].type);
            console.log('L.41 replyToken=' + replyToken);
            console.log('L.60 body.events[0].source.userId=' + userID);

            //イベントタイプ毎に処理を分ける
            if (body.events[0].type == 'things') {
                //応答内容編集                    
                const msg = '冷蔵庫のコーラがストック不足です。' +
                    '山本さんに連絡しますので、いまどこの冷蔵庫の前なのか、場所を教えてね。';
                const replyMessage = messageObject.messageObject_quickreply(msg);
                console.log('L.52 replyMessage=' + replyMessage); //デバッグ
                client.replyMessage(replyToken, replyMessage)
                    .then((response) => {
                        let lambdaResponse = messageObject.lambdaResponse();
                        context.succeed(lambdaResponse);
                    }).catch((err) => console.log(err));

            } else if (body.events[0].type == 'message' && body.events[0].message.type == 'location') {
                //クイックリプライで位置情報が送られてきた場合はこちら

                //応答内容編集                    
                // const msg = '位置情報を記録しました。補充依頼をslackに出しました。';
                const msg = '冷蔵庫の位置情報を山本さんに連絡しました。ご協力ありがとうございました！';
                const replyMessage = messageObject.messageObject_text(msg);
                console.log('L.52 replyMessage=' + replyMessage); //デバッグ

                // //slackにメッセージ送る　ここから
                //slackへのpost内容をまとめ
                // const http = require('http');
                // const HOST = `hooks.slack.com`;
                // const PATH = `/services/T0HT5U8RY/BPBC6A9C0/we2sX9DVD1YcFK6Lj6LFvsGg`;

                var map_url = "https://www.google.co.jp/maps/@" +
                    body.events[0].message.latitude + ',' +
                    body.events[0].message.longitude + ',';
                var sendtext = "超重要なお知らせです。オフィスのコーラが不足してしまいました。補充しないとです。　" + map_url;

                let postData = {
                    // "text": "{とても重要なことが起こりました！詳しくは、<https://alert-system.com/alerts/1234|ここをクリック>してください！}"
                    "channel": "#linethings-demo",
                    "username": "webhookbot",
                    "text": sendtext,
                    "icon_emoji": ":ghost:"
                }
                //curl -X POST --data-urlencode "payload={\"channel\": \"#linethings-demo\", \"username\": \"webhookbot\", \"text\": \"これは webhookbot という名のボットから #linethings-demo に投稿されています。\", \"icon_emoji\": \":ghost:\"}" https://hooks.slack.com/services/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

                // let postDataStr = JSON.stringify(postData);
                // var command = "curl -X POST https://hooks.slack.com/services/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 -H 'content-type: application/json' -d '" + postDataStr + "'";
                // exec(command, (err, stdout, stderr) => {
                //     if (err) { console.log(err); }
                //     console.log(stdout);
                // });
                // let postDataStr = JSON.stringify(postData);
                // var command = "curl -X POST https://hooks.slack.com/services/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 -H 'content-type: application/json' -d '" + postDataStr + "'";
                // exec(command, (err, stdout, stderr) => {
                //     if (err) { console.log(err); }
                //     console.log(stdout);
                // });


                let postDataStr = JSON.stringify(postData);
                var args = " -d " + postDataStr + " -H 'Content-Type: application/json' https://hooks.slack.com/services/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";
                exec('curl ' + args, function (error, stdout, stderr) {
                    console.log('stdout: ' + stdout);
                    console.log('stderr: ' + stderr);
                    if (error !== null) {
                        console.log('exec error: ' + error);
                    }
                });



                // bot.say({
                //     channel: 'linethings-demo', //つぶやきたいチャンネル
                //     text: 'WebAPI完成', //つぶやきたい内容
                //     username: 'cola-checker', //つぶやくBot名
                //     icon_url: ''
                // });


                // let postDataStr = JSON.stringify(postData);
                // let options = {
                //     host: HOST,
                //     port: 80,
                //     path: PATH,
                //     method: 'POST',
                //     headers: {
                //         'Content-Type': 'application/json',
                //         'Content-Length': Buffer.byteLength(postDataStr)
                //     }
                // };

                // let req = http.request(options, (res) => {
                //     console.log('STATUS: ' + res.statusCode);
                //     console.log('HEADERS: ' + JSON.stringify(res.headers));
                //     res.setEncoding('utf8');
                //     res.on('data', (chunk) => {
                //         console.log('BODY: ' + chunk);
                //     });
                // });
                // req.on('error', (e) => {
                //     console.log('problem with request: ' + e.message);
                // });
                // req.write(postDataStr);
                // req.end();

                // //slackにメッセージ送る　ここまで

                client.replyMessage(replyToken, replyMessage)
                    .then((response) => {
                        let lambdaResponse = messageObject.lambdaResponse();
                        context.succeed(lambdaResponse);
                    }).catch((err) => console.log(err));
            } else {

                //クイックリプライでもThingsでもない

                //応答内容編集                    
                // const msg = 'LINEthingsに対応したBOTです。コーラ残量チェッカーの電源が入った状態で、LINEの設定メニューからペアリングが必要です。詳しくはこちら';
                // const replyMessage = messageObject.messageObject_text(msg);

                //応答内容編集      （会社に置いてきてしまったので、Thingsのテストができないため、仮でここを使う。）              
                const msg = '冷蔵庫のコーラがストック不足です。' +
                    '山本さんに連絡しますので、いまどこの冷蔵庫の前なのか、場所を教えてね。';
                const replyMessage = messageObject.messageObject_quickreply(msg);
                console.log('L.52 replyMessage=' + replyMessage); //デバッグ
                client.replyMessage(replyToken, replyMessage)
                    .then((response) => {
                        let lambdaResponse = messageObject.lambdaResponse();
                        context.succeed(lambdaResponse);
                    }).catch((err) => console.log(err));


                console.log('L.52 replyMessage=' + replyMessage); //デバッグ


                client.replyMessage(replyToken, replyMessage)
                    .then((response) => {
                        let lambdaResponse = messageObject.lambdaResponse();
                        context.succeed(lambdaResponse);
                    }).catch((err) => console.log(err));
            }

        }

    } else {
        console.log('署名認証エラー');
    }
};
